﻿namespace CadastroVeiculos
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.rbOnibus = new System.Windows.Forms.RadioButton();
            this.rbCaminhao = new System.Windows.Forms.RadioButton();
            this.lbPlaca = new System.Windows.Forms.Label();
            this.lbAno = new System.Windows.Forms.Label();
            this.tbAno = new System.Windows.Forms.TextBox();
            this.btCadastrar = new System.Windows.Forms.Button();
            this.btLimpar = new System.Windows.Forms.Button();
            this.pbImagens = new System.Windows.Forms.PictureBox();
            this.lv1 = new System.Windows.Forms.ListView();
            this.colPlaca = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colAno = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colAssentos = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colEixos = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colDiaria = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.pnOnibus = new System.Windows.Forms.Panel();
            this.pnCaminhao = new System.Windows.Forms.Panel();
            this.tbEixos = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.tbAssentos = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.mtbPlaca = new System.Windows.Forms.MaskedTextBox();
            ((System.ComponentModel.ISupportInitialize)(this.pbImagens)).BeginInit();
            this.pnOnibus.SuspendLayout();
            this.pnCaminhao.SuspendLayout();
            this.SuspendLayout();
            // 
            // rbOnibus
            // 
            this.rbOnibus.AutoSize = true;
            this.rbOnibus.Location = new System.Drawing.Point(36, 25);
            this.rbOnibus.Name = "rbOnibus";
            this.rbOnibus.Size = new System.Drawing.Size(70, 20);
            this.rbOnibus.TabIndex = 1;
            this.rbOnibus.TabStop = true;
            this.rbOnibus.Text = "Ônibus";
            this.rbOnibus.UseVisualStyleBackColor = true;
            this.rbOnibus.CheckedChanged += new System.EventHandler(this.radioButton1_CheckedChanged);
            // 
            // rbCaminhao
            // 
            this.rbCaminhao.AutoSize = true;
            this.rbCaminhao.Location = new System.Drawing.Point(236, 25);
            this.rbCaminhao.Name = "rbCaminhao";
            this.rbCaminhao.Size = new System.Drawing.Size(89, 20);
            this.rbCaminhao.TabIndex = 2;
            this.rbCaminhao.TabStop = true;
            this.rbCaminhao.Text = "Caminhão";
            this.rbCaminhao.UseVisualStyleBackColor = true;
            this.rbCaminhao.CheckedChanged += new System.EventHandler(this.rbCaminhao_CheckedChanged);
            // 
            // lbPlaca
            // 
            this.lbPlaca.AutoSize = true;
            this.lbPlaca.Location = new System.Drawing.Point(64, 70);
            this.lbPlaca.Name = "lbPlaca";
            this.lbPlaca.Size = new System.Drawing.Size(42, 16);
            this.lbPlaca.TabIndex = 4;
            this.lbPlaca.Text = "Placa";
            // 
            // lbAno
            // 
            this.lbAno.AutoSize = true;
            this.lbAno.Location = new System.Drawing.Point(75, 109);
            this.lbAno.Name = "lbAno";
            this.lbAno.Size = new System.Drawing.Size(31, 16);
            this.lbAno.TabIndex = 5;
            this.lbAno.Text = "Ano";
            // 
            // tbAno
            // 
            this.tbAno.Location = new System.Drawing.Point(112, 106);
            this.tbAno.Name = "tbAno";
            this.tbAno.Size = new System.Drawing.Size(100, 22);
            this.tbAno.TabIndex = 6;
            // 
            // btCadastrar
            // 
            this.btCadastrar.Location = new System.Drawing.Point(54, 189);
            this.btCadastrar.Name = "btCadastrar";
            this.btCadastrar.Size = new System.Drawing.Size(106, 30);
            this.btCadastrar.TabIndex = 5;
            this.btCadastrar.Text = "Cadastrar";
            this.btCadastrar.UseVisualStyleBackColor = true;
            // 
            // btLimpar
            // 
            this.btLimpar.Location = new System.Drawing.Point(219, 189);
            this.btLimpar.Name = "btLimpar";
            this.btLimpar.Size = new System.Drawing.Size(106, 30);
            this.btLimpar.TabIndex = 10;
            this.btLimpar.Text = "Limpar";
            this.btLimpar.UseVisualStyleBackColor = true;
            this.btLimpar.Click += new System.EventHandler(this.btLimpar_Click);
            // 
            // pbImagens
            // 
            this.pbImagens.Image = global::CadastroVeiculos.Properties.Resources.ImagemCaminhao;
            this.pbImagens.Location = new System.Drawing.Point(415, 25);
            this.pbImagens.Name = "pbImagens";
            this.pbImagens.Size = new System.Drawing.Size(180, 182);
            this.pbImagens.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbImagens.TabIndex = 11;
            this.pbImagens.TabStop = false;
            this.pbImagens.Click += new System.EventHandler(this.pbImagens_Click);
            // 
            // lv1
            // 
            this.lv1.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.colPlaca,
            this.colAno,
            this.colAssentos,
            this.colEixos,
            this.colDiaria});
            this.lv1.HideSelection = false;
            this.lv1.Location = new System.Drawing.Point(22, 237);
            this.lv1.Name = "lv1";
            this.lv1.Size = new System.Drawing.Size(589, 145);
            this.lv1.TabIndex = 12;
            this.lv1.UseCompatibleStateImageBehavior = false;
            this.lv1.View = System.Windows.Forms.View.Details;
            this.lv1.SelectedIndexChanged += new System.EventHandler(this.lv1_SelectedIndexChanged);
            // 
            // colPlaca
            // 
            this.colPlaca.Text = "Placa";
            this.colPlaca.Width = 87;
            // 
            // colAno
            // 
            this.colAno.Text = "Ano";
            this.colAno.Width = 48;
            // 
            // colAssentos
            // 
            this.colAssentos.Text = "Assentos";
            this.colAssentos.Width = 72;
            // 
            // colEixos
            // 
            this.colEixos.Text = "Eixos";
            this.colEixos.Width = 51;
            // 
            // colDiaria
            // 
            this.colDiaria.Text = "Diária";
            this.colDiaria.Width = 315;
            // 
            // pnOnibus
            // 
            this.pnOnibus.Controls.Add(this.pnCaminhao);
            this.pnOnibus.Controls.Add(this.tbAssentos);
            this.pnOnibus.Controls.Add(this.label1);
            this.pnOnibus.Location = new System.Drawing.Point(12, 134);
            this.pnOnibus.Name = "pnOnibus";
            this.pnOnibus.Size = new System.Drawing.Size(313, 34);
            this.pnOnibus.TabIndex = 13;
            // 
            // pnCaminhao
            // 
            this.pnCaminhao.Controls.Add(this.tbEixos);
            this.pnCaminhao.Controls.Add(this.label2);
            this.pnCaminhao.Location = new System.Drawing.Point(0, 0);
            this.pnCaminhao.Name = "pnCaminhao";
            this.pnCaminhao.Size = new System.Drawing.Size(313, 34);
            this.pnCaminhao.TabIndex = 2;
            // 
            // tbEixos
            // 
            this.tbEixos.Location = new System.Drawing.Point(100, 6);
            this.tbEixos.Name = "tbEixos";
            this.tbEixos.Size = new System.Drawing.Size(100, 22);
            this.tbEixos.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(54, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(40, 16);
            this.label2.TabIndex = 0;
            this.label2.Text = "Eixos";
            // 
            // tbAssentos
            // 
            this.tbAssentos.Location = new System.Drawing.Point(102, 9);
            this.tbAssentos.Name = "tbAssentos";
            this.tbAssentos.Size = new System.Drawing.Size(98, 22);
            this.tbAssentos.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(8, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(87, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "Qtd Assentos";
            // 
            // mtbPlaca
            // 
            this.mtbPlaca.Location = new System.Drawing.Point(112, 70);
            this.mtbPlaca.Mask = "LLL-0000";
            this.mtbPlaca.Name = "mtbPlaca";
            this.mtbPlaca.Size = new System.Drawing.Size(100, 22);
            this.mtbPlaca.TabIndex = 3;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(636, 394);
            this.Controls.Add(this.mtbPlaca);
            this.Controls.Add(this.pnOnibus);
            this.Controls.Add(this.lv1);
            this.Controls.Add(this.pbImagens);
            this.Controls.Add(this.btLimpar);
            this.Controls.Add(this.btCadastrar);
            this.Controls.Add(this.tbAno);
            this.Controls.Add(this.lbAno);
            this.Controls.Add(this.lbPlaca);
            this.Controls.Add(this.rbCaminhao);
            this.Controls.Add(this.rbOnibus);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pbImagens)).EndInit();
            this.pnOnibus.ResumeLayout(false);
            this.pnOnibus.PerformLayout();
            this.pnCaminhao.ResumeLayout(false);
            this.pnCaminhao.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.RadioButton rbOnibus;
        private System.Windows.Forms.RadioButton rbCaminhao;
        private System.Windows.Forms.Label lbPlaca;
        private System.Windows.Forms.Label lbAno;
        private System.Windows.Forms.TextBox tbAno;
        private System.Windows.Forms.Button btCadastrar;
        private System.Windows.Forms.Button btLimpar;
        private System.Windows.Forms.PictureBox pbImagens;
        private System.Windows.Forms.ListView lv1;
        private System.Windows.Forms.Panel pnOnibus;
        private System.Windows.Forms.Panel pnCaminhao;
        private System.Windows.Forms.TextBox tbEixos;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox tbAssentos;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ColumnHeader colPlaca;
        private System.Windows.Forms.ColumnHeader colAno;
        private System.Windows.Forms.ColumnHeader colAssentos;
        private System.Windows.Forms.ColumnHeader colEixos;
        private System.Windows.Forms.ColumnHeader colDiaria;
        private System.Windows.Forms.MaskedTextBox mtbPlaca;
    }
}

