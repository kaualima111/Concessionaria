﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Rebar;

namespace CadastroVeiculos
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            lv1.View = View.Details; // Modo de exibição
            lv1.Columns.Add("Placa", 100);
            lv1.Columns.Add("Ano", 50);
            lv1.Columns.Add("Assentos", 50);
            lv1.Columns.Add("Eixos", 50);
            lv1.Columns.Add("Valor Diária", 100);
            MessageBox.Show($"Adicionando:");
        }

        private void pbImagens_Click(object sender, EventArgs e)
        {

        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            pbImagens.Image = Properties.Resources.ImagemOnibus;
            ocultaPainel();
            pnOnibus.Visible = true;
        }
        private void ocultaPainel()
        {
            pnOnibus.Visible = false;
            pnCaminhao.Visible = false;
        }

        private void rbCaminhao_CheckedChanged(object sender, EventArgs e)
        {
            pbImagens.Image = Properties.Resources.ImagemCaminhao;
            ocultaPainel();
            pnCaminhao.Visible = true;
        }

        private void lv1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btCadastrar_Click(object sender, EventArgs e)
        {
            if (tbAno.Text == "")
            {
                MessageBox.Show("Ano não pode ser vazio");
                tbAno.Focus();
                return;
            }
            if (mtbPlaca.Text == "")
            {
                MessageBox.Show("Placa não pode ser vazia");
                mtbPlaca.Focus();
                return;
            }

            string[] pr = new string[5];
            pr[0] = mtbPlaca.Text;
            pr[1] = tbAno.Text;

            if (rbCaminhao.Checked)
            {
                if (tbEixos.Text == "")
                {
                    MessageBox.Show("Eixos não podem ser vazios");
                    tbEixos.Focus();
                    return;
                }

                Veiculo v1 = new Caminhao(Convert.ToInt32(tbAno.Text), mtbPlaca.Text, Convert.ToInt32(tbEixos.Text));
                double valorDiaria = v1.CalcularDiaria(DateTime.Now.Year);
                pr[2] = ""; // Para ônibus
                pr[3] = tbEixos.Text;
                pr[4] = valorDiaria.ToString();
            }
            else if (rbOnibus.Checked)
            {
                if (tbAssentos.Text == "")
                {
                    MessageBox.Show("Assentos não podem ser vazios");
                    tbAssentos.Focus();
                    return;
                }

                Veiculo v2 = new Onibus(Convert.ToInt32(tbAno.Text), mtbPlaca.Text, Convert.ToInt32(tbAssentos.Text));
                double valorDiaria = v2.CalcularDiaria(DateTime.Now.Year);
                pr[2] = tbAssentos.Text;
                pr[3] = ""; // Para caminhão
                pr[4] = valorDiaria.ToString();
            }

            ListViewItem l = new ListViewItem(pr);
            lv1.Items.Add(l);
        }
    

        private void lbAssentos_Click(object sender, EventArgs e)
        {

        }

        private void btLimpar_Click(object sender, EventArgs e)
        {
            tbAno.Clear();
            tbAssentos.Clear();
            mtbPlaca.Clear();
            tbEixos.Clear();
        }
    }
}
